use strict;


my %friends;

open FRIEND, 'friend.ini';
my $line;
while ($line = <FRIEND>) {
		chomp($line);
	my @a = split(/=/, $line);
	$friends{$a[0]} = $a[1];
}
close FRIEND;



sub callinfo {
	my $win = $main::winfo;
	my $call = $main::qso{'call'};
	my @info = &dxcc($call);

	if ($call eq '') { return 0; }


	addstr($win, 0, 0, "$info[7] - $info[0]".' 'x80);
	addstr($win, 1, 0, "CQZ: $info[1], ITU: $info[2]".' 'x80);
	addstr($win, 2, 0, "Name: $friends{$call}".' 'x80) if defined ($friends{$call});


	refresh($win);
	return 0;
}


return 1;
