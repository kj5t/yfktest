sub writelog {
		my $i;
		my $cn = $main::cabrilloname;
		my @cabvalues;		# values of the cbr file, like mode, date,	freq...

		my %freq = (160 => 1800, 80 => 3500, 40 => 7000, 20 => 14000,
				15=>21000, 10 => 28000);

		# cabrillo first
		open CBR, ">$filename.cbr";

		# for stuff like CQ-WPX-CW ...
		$cn =~ s/!MODE!/$main::modes/;

		print CBR "START-OF-LOG: 3\n";
		print CBR "CALLSIGN: $main::mycall\n";
		print CBR "CATEGORY-ASSISTED: $main::assisted\n";
		print CBR "CATEGORY-BAND: $main::bands\n";
		print CBR "CATEGORY-MODE: $main::modes\n";
		print CBR "CATEGORY-OPERATOR: $main::operator\n";
		print CBR "CATEGORY-POWER: $main::power\n";
		print CBR "CATEGORY-TRANSMITTER: $main::transmitter\n";
		print CBR "CLAIMED-SCORE: $main::s_sum\n";
		print CBR "CLUB: \n";
		print CBR "CONTEST: $cn\n";
		print CBR "CREATED-BY: YFKtest $main::version\n";
		print CBR "LOCATION: \n" if ($main::contest eq 'IOTA');
		print CBR "NAME: \n";
		print CBR "ADDRESS: \n";
		print CBR "ADDRESS: \n";
		print CBR "ADDRESS: \n";
		print CBR "ADDRESS: \n";
		print CBR "OPERATORS: $main::mycall \n";
		print CBR "SOAPBOX: \n";

		# actual log...
		@cabvalues = split(/\s+/, $cabrillovalues);
		foreach $i (0.. $#main::qsos) {

				my @values;

				foreach (@cabvalues) {
					if ($_ eq 'mycall') {
						push @values, $main::mycall;
					}
					elsif ($_ eq 'band') {
						push @values, $freq{$main::qsos[$i]{'band'}};
					}
					elsif ($_ =~ /^rst/) {
						if ($main::qsos[$i]{'mode'} eq 'SSB') {
							push @values, '59';
						}
						else {
							push @values, '599';
						}
					}
					elsif ($_ eq 'mode') {
						if ($main::qsos[$i]{'mode'} eq 'SSB') {
							push @values, 'PH';
						}
						else {
							push @values, 'CW';
						}
					}
					elsif ($_ eq 'exc1s') {
							push @values, $main::exc1s;
					}
					elsif ($_ eq 'exc2s') {
							push @values, $main::exc2s;
					}
					elsif (defined($main::qsos[$i]{$_})) {
						push @values, $main::qsos[$i]{$_};
					}
				}

				if ($main::contest eq 'IOTA') {
					$values[11] .= '------' unless $values[11];
				}
				
				print CBR sprintf($cabrilloline."\n", @values);
		}
		
		print CBR "END-OF-LOG:\n";
		close CBR;


		# ADIF
		open ADIF, ">$filename.adi";

		print ADIF "YFKtest log for $main::mycall in $main::contest Contest".
					"\n\n<eoh>\n";

		foreach $i (0.. $#main::qsos) {

			print ADIF "<call:".length($main::qsos[$i]{'call'}).'>'.
					$main::qsos[$i]{'call'}.' ';

			my $date = $main::qsos[$i]{'date'};
			$date =~ s/-//g;
			print ADIF "<qso_date:8>".$date.' ';
			print ADIF "<time_on:4>".$main::qsos[$i]{'utc'}."\n";

			print ADIF "<band:".(length($main::qsos[$i]{'band'})+1).'>'.
					$main::qsos[$i]{'band'}.'m  ';
			print ADIF "<mode:".length($main::qsos[$i]{'mode'}).'>'.
					$main::qsos[$i]{'mode'}.'  ';

			my $rst = '599';
			if ($main::qsos[$i]{'mode'} eq 'SSB') { 
					$rst = '59';
			}

			print ADIF "<rst_sent:".length($rst).'>'.$rst.' ';
			print ADIF "<rst_rcvd:".length($rst).'>'.$rst.' ';
			
			print ADIF "<stx:".length($i+1).'>'.($i+1).' ';

			if ($main::qsos[$i]{'exc1'} =~ /^\d+$/) {	
				print ADIF "<rtx:".length($main::qsos[$i]{'exc1'}).'>'.
					($main::qsos[$i]{'exc1'}+1).' ';
			}

			print ADIF "\n";

			# contest specific exchanges...
			if (($main::contest eq 'IOTA') && $main::qsos[$i]{'exc2'}) {
				print ADIF "<iota:6>".$main::qsos[$i]{'exc2'}.' ';

			}
			elsif ($main::contest eq 'CQWW') {
				print ADIF "<cqz:".length($main::qsos[$i]{'exc1'}).'>'.
						$main::qsos[$i]{'exc1'}.' ';
			}
			elsif (($main::contest eq 'IARU') && 
					($main::qsos[$i]{'exc1'} =~ /^\d+$/)) {
				print ADIF "<ituz:".length($main::qsos[$i]{'exc1'}).'>'.
						$main::qsos[$i]{'exc1'}.' ';

			}

			print ADIF "\n<eor>\n\n";

		}


		close ADIF;

	curs_set(0);
	addstr($main::wmain, 23,18, "Files written...");
	refresh($main::wmain);
	sleep 1;
	addstr($main::wmain, 23,18, "                ");
	refresh($main::wmain);

	return 1;

}

return 1;
