# Check-Multi

sub checkcall {
	my $window = $_[0];
	my @qsos = @{$_[1]};
	my $call = $_[2];

	my $ypos=1;

	curs_set(0);
	addstr($$window, 0, 0, ' ' x 240);
	attron($$window, A_BOLD);
	addstr($$window, 0, 8, 'Check Call');
	attroff($$window, A_BOLD);
	refresh($$window);


	if (length($call) < 2) { return 1; };

	foreach my $i (0 .. $#qsos) {
		
		if ($qsos[$i]{'call'} =~ /^$call/) {

			my $band = $qsos[$i]{'band'};

			if ($band == 160) {
					$ypos = 1;
			}
			elsif ($band == 80) {
					$ypos = 2;
			}
			elsif ($band == 40) {
					$ypos = 3;
			}
			elsif ($band == 20) {
					$ypos = 4;
			}
			elsif ($band == 15) {
					$ypos = 5;
			}
			elsif ($band == 10) {
					$ypos = 6;
			}
	
			addstr($$window, $ypos, 0, sprintf("%-4s %3s %s %-10s %s",
						($i+1), $qsos[$i]{'band'}, $qsos[$i]{'utc'},
						$qsos[$i]{'call'}, $qsos[$i]{'exc1'}));
			}

			#addstr($$window, 6, 1, '1652   10 1421 KC1XX     03');


	}
	refresh($$window);
}


return 1;
