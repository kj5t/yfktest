sub qsy {
	if ($_[0]->{'call'} =~ /^(10|15|20|40|80|160)M$/) {
		$_[0]->{'band'} = $1;
		$_[0]->{'call'} = '';
		${$_[1]} = 0;				# cursor position
	}
	elsif ($_[0]->{'call'} =~ /^(CW|SSB|RTTY)$/) {
		$_[0]->{'mode'} = $1;
		$_[0]->{'call'} = '';
		${$_[1]} = 0;				# cursor position

		if ($1 eq 'SSB') {
			$_[0]->{'rst'} = '59';
		}
		else {
			$_[0]->{'rst'} = '599';
		}

	}


}

return 1;
