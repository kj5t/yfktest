
sub scoreqso {
	require "dxcc.pl";
	
	my %qso = %{$_[0]};
	my $qsoref = $_[1];		# ref to QSO AoH
	my $s_qsos = $_[2];
	my $s_qsopts = $_[3];
	my $s_mult1 = $_[4];
	my $s_mult2 = $_[5];
	my $s_dupes = $_[6];

	# IOTA test
#	$defqsopts = 'dx=5~cont=3~own=1~exc2=((AF|AS|NA|SA|EU|AN)\d{3,3})=15';
#	$defqsopts = 'dx=6~cont=3~own=1~exc2=((AF|AS|NA|SA|EU|AN)\d{3,3})=15';

	# Check for dupe
	foreach (@{$qsoref}) {
		if (($_->{'call'} eq $qso{'call'}) &&
			($_->{'band'} eq $qso{'band'}) &&
			($_->{'mode'} eq $qso{'mode'}) &&	
			($_->{'nr'} < $qso{'nr'}-1)) {
				$s_dupes->{$qso{'band'}}++;
				return 1;
		}
	}	

	# Not a dupe if here, so do scoring
	
	$s_qsos->{$qso{'band'}}++;

	# QSO-Points can be determined by:
	# * Nothing; fixed
	# * DX=x, same Cont=y, same DXCC=z, $field matching $regex = p

	if ($main::defqsopts eq 'iaru') {
		(my $cont, undef) = &dxcc($qso{'call'});

		if ($qso{'exc1'} =~ /^\d+$/) {		# ITU Zone
			if ($main::exc1s eq $qso{'exc1'}) {
				$s_qsopts->{$qso{'band'}} += 1;
			}
			elsif ($cont eq $main::mycont) {
				$s_qsopts->{$qso{'band'}} += 3;
			}
			else {
				$s_qsopts->{$qso{'band'}} += 5;
			}
		}
		else {	# HQ or R123/AC. The latter will be wrong but I don't care
				$s_qsopts->{$qso{'band'}} += 1;
		}
	}
	elsif ($main::defqsopts =~ /fixed=(\d+)/) {
			$s_qsopts->{$qso{'band'}} += $1;
	}
	elsif ($main::defqsopts eq 'wpx') {
			my $dxpts = 3;
			my $contpts = 1;
			my $ownpts = 1;

			my ($cont, $dxcc) = &dxcc($qso{'call'});


			if (($cont eq $main::mycont) && ($main::mycont eq 'NA')) {
				$contpts = 2;
			}
			
			if ($qso{'band'} > 20) {
				$dxpts *= 2;
				$contpts *= 2;
			}

			if ($main::mycont ne $cont) {
				$s_qsopts->{$qso{'band'}} += $dxpts;
			}
			elsif ($main::mydxcc ne $dxcc) {
				$s_qsopts->{$qso{'band'}} += $contpts;
			}
			else {
				$s_qsopts->{$qso{'band'}} += $ownpts;
			}
	}	#dx,cont,own,regex
	elsif($main::defqsopts=~/dx=(\d+)~cont=(\d+)~own=(\d+)~(\w+)=(.+?)=(\d+)/) {
			my $dxpts = $1;
			my $contpts = $2;
			my $ownpts = $3;
			my $field = $4;
			my $regex = $5;
			my $specialpts = $6;

			my ($cont, $dxcc) = &dxcc($qso{'call'});

			if ($qso{$field} =~ /$regex/) {	

				if ($main::contest eq 'IOTA') {
						my $iota = $qso{'exc2'};
						$iota =~ s/([A-Z]{2})/$1-/;
						if ($iota eq $main::exc2s) {	#same island
							$specialpts = 3;
						}
				}

				$s_qsopts->{$qso{'band'}} += $specialpts;

			}
			elsif ($main::mycont ne $cont) {
				$s_qsopts->{$qso{'band'}} += $dxpts;
			}
			elsif ($main::mydxcc ne $dxcc) {
				$s_qsopts->{$qso{'band'}} += $contpts;
			}
			else {
				$s_qsopts->{$qso{'band'}} += $ownpts;
			}
	}	#dx,cont,own,regex

#	print STDERR $s_qsopts->{$qso{'band'}}."\n";



	# Mult 1 - can be one of the following:
	#  * Prefix
	#  * DXCC
	#  * DXCC+WAE
	#  * exch1..4

	if ($main::defmult1 =~ /prefix-(.+)/) {
		my $prefix;
		my $bands = $1;

		# get rid of inimportant appendixes...	
		if (index($qso{'call'}, '/') > -1) {
			$qso{'call'} =~ s/((\/QRP)|(\/P)|(\/M)|(\/A))//g;
		}

		if (index($qso{'call'}, '/') < 0) {
			$qso{'call'} =~ /^(.+?)[A-Z]+$/;
			$prefix = $1;
		}
		else {
				my $x;
				my @a = split(/\//, $qso{'call'});
				
				# put the addition to a[0], main call to a[1]
				unless (length($a[0]) < length($a[1])){
						($a[0], $a[1]) = ($a[1], $a[0]);
				}

				if ($a[0] =~ /[A-Z][0-9]+$/) {		# W4/DJ1YFK -> W4
						$prefix = $a[0];
				}
				elsif ($a[0] =~ /^[A-Z]+$/) {		# OH/DJ1YFK -> OH0
						$prefix = $a[0].'0';
				}
				elsif ($a[0] =~ /^[0-9]$/) {		# DJ1YFK/3 -> DJ3
						$qso{'call'} =~ /^(.+?)[0-9]/;
						$prefix = $1.$a[0];
				}
				else {								# Unknown case...
						$qso{'call'} =~ /^(.+?)[A-Z]+$/;
						$prefix = $1;
				}
		}

		if ($bands eq 'band') {	# mults by band
			if (index($s_mult1->{$qso{'band'}}, " $prefix ") == -1) {
					$s_mult1->{$qso{'band'}} .= " $prefix ";
			}
		}
		else {					# mults over all bands
			if (index($s_mult1->{'All'}, " $prefix ") == -1) {
					$s_mult1->{'All'} .= " $prefix ";
			}
		}



	} # defmult1=prefix
	elsif (($main::defmult1 =~ /(exc\d)-(\w+)-(\w+)/) &&
			($qso{$1} ne '')) {			# might be empty, like in IOTA..
		my $mult = $qso{$1};

		# $2 can be 'band' or 'all', $3 can be 'mode' or 'all'.

		if ($2 eq 'band') {
			if ($3 eq 'all') {		# regardless of mode
				unless ($s_mult1->{$qso{'band'}} =~ / $mult /) {
						$s_mult1->{$qso{'band'}} .= " $mult ";
				}
			}
			elsif ($3 eq 'mode') {
				unless ($s_mult1->{$qso{'band'}} =~ / $mult$qso{'mode'} /) {
						$s_mult1->{$qso{'band'}} .= " $mult$qso{'mode'} ";
				}
			}
		}
		else {	# mults over all bands
			if ($3 eq 'all') {
				unless ($s_mult1->{'All'} =~ / $mult /) {
						$s_mult1->{'All'} .= " $mult ";
				}
			}
			elsif ($3 eq 'mode') {
				unless ($s_mult1->{'All'} =~ / $mult$qso{'mode'} /) {
						$s_mult1->{'All'} .= " $mult$qso{'mode'} ";
				}
			}
		}
	}


	# Total points

	# sum of mults: FIXME: maybe not bandwise in wpx etc.


	my	$multsum = &count($s_mult1->{160}) + &count($s_mult1->{80}) +
				&count($s_mult1->{40}) + &count($s_mult1->{20}) + 
				&count($s_mult1->{15}) + &count($s_mult1->{10}) +
				&count($s_mult1->{'All'});



	my $qsoptsum = $s_qsopts->{160} + $s_qsopts->{80} + $s_qsopts->{40} + 
		$s_qsopts->{20} + $s_qsopts->{15} + $s_qsopts->{10}; 

	${$_[7]} = $qsoptsum * $multsum;



}


return 1;
