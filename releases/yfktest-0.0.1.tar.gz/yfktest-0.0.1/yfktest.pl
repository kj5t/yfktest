#!/usr/bin/perl -w

# yfktest - a simple, single operator ham radio contest logbook
# 
# Copyright (C) 2007  Fabian Kurz, DJ1YFK
#
# This program is free software; you can redistribute it and/or modify 
# it under the terms of the GNU General Public License as published by 
# the Free Software Foundation; either version 2 of the License, or 
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, 
# but WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License 
# along with this program; if not, write to the 
# Free Software Foundation, Inc., 59 Temple Place - Suite 330, 
# Boston, MA 02111-1307, USA. 

use strict;
use Curses;
use IO::Socket;

# XXX XXX

our $cwspeed=32;

our $cwsocket = IO::Socket::INET->new(PeerAddr => "localhost",
PeerPort => "6789", Proto    => "udp", Type     => SOCK_DGRAM,)
or die "Cannot open socket for CWdaemon.\n";

print $cwsocket chr(27)."2 $cwspeed";

require "newcontest.pl";
require "checkmulti1.pl";
require "checkcall.pl";
require "showscore.pl";
require "partialcheck.pl";
require "readakey.pl";
require "wipeqso.pl";
require "qsy.pl";
require "logqso.pl";
require "displaylog.pl";
require "scoreqso.pl";
require "readlog.pl";
require "dupecheck.pl";
require "rate.pl";
require "readrules.pl";
require "writelog.pl";
require "sendcw.pl";
require "dxcc.pl";

our $version = "0.0.1";

our ($contest,			# definition file: defs/$contest.def
	$filename,			# of this current contest log
	$mycall,
	$assisted,			# for cabrillo log
	$bands,				
	$modes,	
	$operator,
	$power,
	$transmitter);

our $entryfields = 1;	# contest dependant
our $activefield = 'call';

# printf-string for the cabrillo output
our $cabrilloline='no cabrillo format defined!';
our $cabrillovalues='band date utc ...';
our $cabrilloname='CONTEST-NAME';

our ($exc1len, $exc2len, $exc3len, $exc4len) = (4,4,4,4);

our $fixexchange='';		# fixed exchange like in IOTA, ITU etc.
						# contains which exchange will be fixed, i.e. exc1, 2..
our $fixexchangename='';# what to ask the user for, like "IOTA-Ref:"?
our $exc1s = '';		# actual value of the fixed exchange value
our $exc2s = '';

our $tmp='';

my $curpos = 0;

# Valid characters for the 4 entry fields  (will be read from def file)
our @validchars = ('[0-9A-Za-z]', '', '', '');

# Valid complete entries that can be logged (example: IOTA) (will be read fm
# def file)
our @validentry = ('.+', '', '', '');


my $oldcall=''; 			# check if call was changed. otherwise no PC/SPC

our %s_qsos = ("160" =>0,"80" => 0, "40" => 0, "20" => 0, "15" => 0, "10" => 0);
our %s_qsopts = ("160" =>0,"80" => 0, "40" => 0, "20" => 0, "15" => 0, "10" => 0);
our %s_mult1 = ("160" => 0,"80"=> 0, "40" => 0, "20" => 0, "15" => 0, "10" => 0, "All" => 0);
our %s_mult2 = ("160" => 0,"80"=> 0, "40" => 0, "20" => 0, "15" => 0, "10" => 0, "All" => 0);
our %s_dupes = ("160" => 0,"80" => 0,"40" => 0, "20" => 0, "15" => 0, "10" => 0, "All" => 0);
our $s_sum = 0;


our ($defmult1, $defmult2, $defqsopts);


our @qsos;			# Array of hashes with single QSOs.

our @cwmessages  = ('');


open SCP, "master.scp";
our @scp = <SCP>;
$scp[1] = $scp[2] = '';
close SCP;

our %qso = (		# The current QSO
		'nr' => 1,
		'utc' => '',
		'date' => '20070101',
		'call' => '',
		'rst' => '599',
		'excs' => '',		# sent exchange
		'exc1' => '',
		'exc2' => '',
		'exc3' => '',
		'exc4' => '',
		'band' => '20',
		'mode' => 'CW');


$mycall = 'DJ1YFK';

our $mycont='EU';
our $mydxcc='DL';

initscr();
noecho();
keypad(1);

if (!has_colors) {
		die "Your terminal can't display colors.";
}

start_color();
curs_set(0);

printw "YFKtest v$version - Copyright (C) 2007 Fabian Kurz, DJ1YFK
This is free software, and you are welcome to redistribute it
under certain conditions (see COPYING).

Press any key to continue.";

getch();

halfdelay(1);

init_pair(1, COLOR_BLACK, COLOR_YELLOW);
init_pair(2, COLOR_BLUE, COLOR_GREEN);
init_pair(3, COLOR_BLUE, COLOR_CYAN);
init_pair(4, COLOR_WHITE, COLOR_BLUE);
init_pair(5, COLOR_WHITE, COLOR_BLACK);

# If a file was supplied as command line argument, continue this contest,
# otherwise start a new contest.

if ($ARGV[0]) {
		if (-r $ARGV[0]) {
			printw "\nOpening log file $ARGV[0]...\n";
			$filename = $ARGV[0];

			unless (($contest = &readlog()) &&
					($qso{'nr'} = $#qsos+2) 
			) {
				printw "$ARGV[0] not a valid contest log! Exiting.\n";
				getch; endwin; exit;
			} else {					# Read log OK, now rescore!

					# read the rules and fill neccessary variables...
					&readrules($contest);

					if ($tmp) {
						if ($fixexchange eq 'exc1s') {
							$exc1s = $tmp;
						}
						elsif ($fixexchange eq 'exc2s') {
							$exc2s = $tmp;
						}
					}


					printw "Rescoring the log: ";
					my $i = 0;

					($mycont, $mydxcc) = &dxcc($mycall);

					foreach (@qsos) {
						$i++;
						if ($i % 10 == 0) { printw $i.' '; }
						refresh();
						%qso = %{$_};
						&scoreqso(\%qso, \@qsos, \%s_qsos, \%s_qsopts,
								\%s_mult1, \%s_mult2, \%s_dupes, \$s_sum);
					}
					&wipeqso(\%qso, \$curpos, \$activefield);
					$qso{'nr'}++;

			}


		}
		else {
			printw "File $ARGV[0] not found. Exiting.";
			getch; endwin; exit;
		}
}
else {

	($contest, $filename, $mycall, $assisted, $bands, $modes, $operator,
			 $power, $transmitter)  = &newcontest($mycall);

}

($mycont, $mydxcc) = &dxcc($mycall);

##############################################################################
# Actual logging starts here
##############################################################################

our $wmain = newwin(24,80,0,0);
attron($wmain, COLOR_PAIR(3));
addstr($wmain, 0,0, ' 'x(24*80));
refresh($wmain);

my $wcheck = newwin(7,30,0,0);
attron($wcheck, COLOR_PAIR(4));

my $wshowscore = newwin(10,21,14,59);
my $wpartialcheck = newwin(9,40,0,39);

our $wrate = newwin(4, 16, 10, 62);
attron($wrate, COLOR_PAIR(4));
addstr($wrate, 0,0, "   QSO Rates:   ");
addstr($wrate, 1,0, " "x66);
addstr($wrate, 3,0, "  CW-Speed: $cwspeed");
refresh($wrate);

my $ch;

# initial display
&showscore(\$wshowscore, \%s_qsos, \%s_mult1, \%s_mult2, \%s_dupes, $s_sum);
&rate(\$wrate, \@qsos);
&displaylog(\$wmain, \@qsos);
&partialcheck(\$wpartialcheck, \%qso, \@qsos, \@scp);
&checkcall(\$wcheck, \@qsos, $qso{'call'});

while (1) {

		#&checkmulti1(\$wcheck, $contest, undef, undef);
		if ($qso{'call'} ne $oldcall) {
			&displaylog(\$wmain, \@qsos);
			&partialcheck(\$wpartialcheck, \%qso, \@qsos, \@scp);
			&checkcall(\$wcheck, \@qsos, $qso{'call'});
			&dupecheck(\$wmain, \%qso, \@qsos);
		}
		$oldcall = $qso{'call'};
		my $ch = &readakey(\$wmain, \%qso, $entryfields, \$activefield,
				\$curpos, \@validchars, \@validentry);	


		if ($ch ne 'ok') {		# some special key/function pressed
			if ($ch =~ /^(f\d|ins|esc|plus|pgup|pgdwn)$/) {
				&sendcw($ch);
			}
			elsif ($ch eq 'wipe') {
				&wipeqso(\%qso, \$curpos, \$activefield);
			}
			elsif ($ch eq 'log') {		# enter pressed
				&qsy(\%qso, \$curpos);	# check for: '20M', 'SSB' etc.
				
				if (&logqso(\%qso, \@qsos, \@validentry, $filename)) {
					if ($qso{'call'} eq 'WRITELOG') {
						&writelog();
					}
					else {
					&scoreqso(\%qso, \@qsos, \%s_qsos, \%s_qsopts, \%s_mult1,
							\%s_mult2, \%s_dupes, \$s_sum);
					}
					&wipeqso(\%qso, \$curpos, \$activefield);
				}
				&showscore(\$wshowscore, \%s_qsos, \%s_mult1, \%s_mult2,
						\%s_dupes, $s_sum);
				&rate(\$wrate, \@qsos);
			}
		}



}







endwin();


