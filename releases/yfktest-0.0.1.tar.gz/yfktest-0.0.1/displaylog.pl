

sub displaylog {
	$window = $_[0];
	@qsos = @{$_[1]};

	my $y = 14;

	my $stop = $#qsos;
	my $start = $stop - 5;

	if ($start < 0) { $start = 0; }




foreach my $i ( $start .. $stop) {

	$y++;

curs_set(0);
addstr($$window, $y, 0, ' 'x59);
#addstr($$window, $y, 0, $i+1);
addstr($$window, $y, 0, $qsos[$i]{'nr'});
addstr($$window, $y, 5, $qsos[$i]{'band'}.'  ');
addstr($$window, $y, 9, $qsos[$i]{'mode'}.'  ');
addstr($$window, $y, 13, $qsos[$i]{'utc'}.'  ');
addstr($$window, $y, 18, $qsos[$i]{'call'}.'            ');
addstr($$window, $y, 31, $qsos[$i]{'rst'}.'   ');
addstr($$window, $y, 37, $qsos[$i]{'exc1'}.'    ');
addstr($$window, $y, 43, $qsos[$i]{'exc2'}.' ');
addstr($$window, $y, 49, $qsos[$i]{'exc3'}.' ');
addstr($$window, $y, 55, $qsos[$i]{'exc4'}.'    ');

}

refresh($$window);



}





return 1;
