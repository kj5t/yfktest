require "gettime.pl";
require "getdate.pl";

sub logqso {
	my %qso = %{$_[0]};
	my @validentry = @{$_[2]};		# regexes
	my $filename = $_[3];

	if ($qso{'call'} eq 'WRITELOG') {
		return 1;
	}

	# check validity of this QSO
	if (
			($qso{'call'} =~ /[A-Z0-9][A-Z0-9][A-Z]/) &&
			($qso{'exc1'} =~ /^$validentry[0]$/) &&
			($qso{'exc2'} =~ /^$validentry[1]$/) &&
			($qso{'exc3'} =~ /^$validentry[2]$/) &&
			($qso{'exc4'} =~ /^$validentry[3]$/)
	) {

		${$_[0]}{'nr'}++;

		$qso{'utc'} = &gettime();
		$qso{'date'} = &getdate();

		if ($main::contest eq 'IOTA') {
			$qso{'exc2'} =~ s/([A-Z]{2})/$1-/;
		}



		push @{$_[1]}, { %qso };

		open LOG, ">>$filename";

		my $logline = sprintf(
				"%-4s %-3s%3s %-4s %-8s %-12s %-6s %-6s %-6s %-6s\n",
				$qso{'nr'}, $qso{'band'}, $qso{'mode'}, $qso{'utc'},
				$qso{'date'}, $qso{'call'}, $qso{'exc1'}, $qso{'exc2'},
				$qso{'exc3'}, $qso{'exc4'});

			print LOG $logline;

		close LOG;

		return 1;
	}
	else {
			return 0;
	}

}



return 1;
