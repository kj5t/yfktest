use strict;
use warnings;

open CTY, "cty.dat";

my %prefixes;			# hash of arrays  main prefix -> (all, prefixes,..)
my %dxcc;				# hash of arrays  main prefix -> (CQZ, ITUZ, ...)
my $mainprefix;

while (my $line = <CTY>) {
	if (substr($line, 0, 1) ne ' ') {			# New DXCC
		$line =~ /\s+([*A-Za-z0-9\/]+):\s+$/;
		$mainprefix = $1;
		$line =~ s/\s{2,}//g;
		@{$dxcc{$mainprefix}} = split(/:/, $line);
	}
	else {										# prefix-line
		$line =~ s/\s+//g;
		unless (defined($prefixes{$mainprefix}[0])) {
			@{$prefixes{$mainprefix}} = split(/,|;/, $line);
		}
		else {
			push(@{$prefixes{$mainprefix}}, split(/,|;/, $line));
		}
	}
}


#foreach (keys %prefixes) {
#	print $_;
#	print " enthaelt: ";
#	print "@{$prefixes{$_}} \n";
#	print "@{$dxcc{$_}}\n";
#	print "-"x70;
#	print "\n";
#}

sub dxcc {

my $testcall = shift;

my $matchchars=0;
my $matchprefix='';
my $test;
my $zones = '';					# annoying zone exceptions
my $goodzone;
my $letter = substr($testcall, 0,1);


foreach $mainprefix (keys %prefixes) {

	foreach $test (@{$prefixes{$mainprefix}}) {
		my $len = length($test);

		if ($letter ne substr($test,0,1)) {			# gains 20% speed
			next;
		}

		$zones = '';

		if (($len > 5) && ((index($test, '(') > -1)			# extra zones
						|| (index($test, '[') > -1))) {
#				print "$test $len -->";
				$test =~ /^([A-Z0-9\/]+)([\[\(].+)/;
				$zones .= "zones: $2" if defined $2;
				$len = length($1);
#				print ">$test  $zones $len< \n";
		}

		if ((substr($testcall, 0, $len) eq substr($test,0,$len)) &&
								($matchchars <= $len))	{
			$matchchars = $len;
			$matchprefix = $mainprefix;
			$goodzone = $zones;
#			print "$matchprefix --> $goodzone \n";
		}
	}
}



return ($dxcc{$matchprefix}[3],$dxcc{$matchprefix}[7]);

}


return 1;


