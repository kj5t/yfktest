use strict;

my %friends;

open FRIEND, 'friend.ini';
my $line;
while ($line = <FRIEND>) {
		chomp($line);
	my @a = split(/=/, $line);
	$friends{$a[0]} = $a[1];
}
close FRIEND;



sub callinfo {
	my $win = $main::winfo;
	my $call = $main::qso{'call'};
	my $contest = $main::contest;
	move($win, 0,0);
	addstr($win, ' 'x1234);
		
	if ($contest eq 'EUHFC') {		# EUHFC = Show Mults wkd/needed.
		my $band = $main::qso{'band'};
		my $mults = $main::s_mult1{$band};

		move($win, 0,0);
		for (my $i=50; $i < 109 ; $i++ ) {
			my $year = sprintf("%02d", ($i%100));
			if ($mults =~ / $year /) {
				attron($win, COLOR_PAIR(2));
			}
			else {
				attron($win, COLOR_PAIR(4));
			}
			addstr($win, $year);
			attron($win, COLOR_PAIR(4));
			addstr($win, " ") unless ($year =~ /61|73|85|97/);
		}
#		addstr($win, 0, 0, $mults);
		refresh($win);

	} # EUHFC
	elsif ($contest eq 'YODX') {	# YO-DX-Contest: Show provinces
		my $band = $main::qso{'band'};
		my $mults = $main::s_mult2{$band};
		my @districts = qw/AB AG AR BC BH BN BR BT BU BV BZ CJ CL CS CT CV DB
		DJ GJ GL GR HD HR IF IL IS MH MM MS NT OT PH SB SJ SM SV TL TM TR VL VN
		VS/;

		move($win, 0,0);
		foreach my $d (@districts) {
			if ($mults =~ / $d /) {
				attron($win, COLOR_PAIR(2));
			}
			else {
				attron($win, COLOR_PAIR(4));
			}
			addstr($win, $d);
			attron($win, COLOR_PAIR(4));
			addstr($win, " ") unless ($d =~ /CJ|IF|SV/);
		}
		addstr($win, 4, 0, "Name: $friends{$call}".' 'x20) if defined ($friends{$call});
		refresh($win);
	} #YODX
	else {							# Show generic callsign info.
	
		my @info = &dxcc($call);
		if ($call eq '') { return 0; }

		addstr($win, 0, 0, "$info[7] - $info[0]".' 'x80);
		addstr($win, 1, 0, "CQZ: $info[1], ITU: $info[2]".' 'x80);
		addstr($win, 2, 0, "Name: $friends{$call}".' 'x80) if defined ($friends{$call});
	refresh($win);
	return 0;

	} # else, generic info


}


return 1;
