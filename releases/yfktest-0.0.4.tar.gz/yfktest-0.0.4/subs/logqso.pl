require "subs/gettime.pl";
require "subs/getdate.pl";

sub logqso {
	my %qso = %{$_[0]};
#	my @validentry = @{$_[2]};		# regexes
	my $filename = $_[3];

	my @validentry = @main::validentry;

	if ($qso{'call'} eq 'WRITELOG') {
		return 1;
	}

	# check validity of this QSO
	if (
			($qso{'call'} =~ /[A-Z0-9][A-Z0-9][A-Z]/) &&
			($qso{'exc1'} =~ /^$validentry[0]$/) &&
			($qso{'exc2'} =~ /^$validentry[1]$/) &&
			($qso{'exc3'} =~ /^$validentry[2]$/) &&
			($qso{'exc4'} =~ /^$validentry[3]$/)
	) {

		${$_[0]}{'nr'}++;

		$qso{'utc'} = &gettime();
		$qso{'date'} = &getdate();

		push @{$_[1]}, { %qso };

		open LOG, ">>$filename";

		my $logline = sprintf(
				"%-4s %-3s%3s %-4s %-8s %-12s %-6s %-6s %-6s %-6s\n",
				$qso{'nr'}, $qso{'band'}, $qso{'mode'}, $qso{'utc'},
				$qso{'date'}, $qso{'call'}, $qso{'exc1'}, $qso{'exc2'},
				$qso{'exc3'}, $qso{'exc4'});

			print LOG $logline;

		close LOG;

		return 1;
	}
	else {
		return 0;
	}

}

# Logging an edited QSO.

sub logeditqso {
		my $success = 0;
		my %qso = %main::qso;		# less typing
		my @validentry = @main::validentry;

		unless (
				($qso{'call'} =~ /[A-Z0-9][A-Z0-9][A-Z]/) &&
				($qso{'exc1'} =~ /^$validentry[0]$/) &&
				($qso{'exc2'} =~ /^$validentry[1]$/) &&
				($qso{'exc3'} =~ /^$validentry[2]$/) &&
				($qso{'exc4'} =~ /^$validentry[3]$/)
		) {
			addstr($main::wmain,23,0, "Invalid data entered QSO not changed!");
			return 0;
		}


		open LOG, $main::filename;
		my @log = <LOG>;
		close LOG;

		# search for the QSO with the same number as $editnr:

		# The number in the array might be different from the actual number, so
		# we search the actual number. Also the band of the original QSO has to
		# match.

#		my $realeditnr = $main::qsos[$editnr]{'nr'};

		for (my $i=0 ; $i <= $#log; $i++) {
			next while ($i < 17);						# HEADER
			if ($log[$i] =~ /^$qso{'nr'}\s+/) {
				$log[$i] =  sprintf(
				"%-4s %-3s%3s %-4s %-8s %-12s %-6s %-6s %-6s %-6s\n",
				$qso{'nr'}, $qso{'band'}, $qso{'mode'}, $qso{'utc'},
				$qso{'date'}, $qso{'call'}, $qso{'exc1'}, $qso{'exc2'},
				$qso{'exc3'}, $qso{'exc4'});
				$success = 1;
				last;
			}

		}

		if ($success) {
			open LOG, ">$main::filename";
			print LOG @log;
			close LOG;
		}

		return $success;
}







return 1;
