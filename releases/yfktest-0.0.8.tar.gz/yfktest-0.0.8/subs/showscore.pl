sub showscore {
	my $window = $_[0];
	my %s_qso = %{$_[1]};
	my %s_mult1 = %{$_[2]};		# 80 => 'HB9 DL1 UU7' -> need to count them!
	my %s_mult2 = %{$_[3]};
	my %s_dupes = %{$_[4]};
	my $s_sum = $_[5];

	my ($t_qso, $t_mult1, $t_mult2) = (0,0,0);

	attron($$window, COLOR_PAIR(4));
	addstr($$window, 0,0, ' 'x999);

	my $y = 2;
	foreach (sort {$a <=> $b} keys %s_qso) {
		$t_qso  += $s_qso{$_};
		$t_mult1  += &count($s_mult1{$_});
		$t_mult2  += &count($s_mult2{$_});
		addstr($$window, $y, 1, "$_");
		addstr($$window, $y, 4, sprintf(" %4d %3d %3d %2d", $s_qso{$_}, 
				&count($s_mult1{$_}), &count($s_mult2{$_}), $s_dupes{$_}));
		$y++;
	}
	attron($$window, COLOR_PAIR(2));


	$t_mult1  += &count($s_mult1{'All'});
	$t_mult2  += &count($s_mult2{'All'});

	1 while $s_sum =~ s/^(\d+)(\d{3,3})/$1,$2/;

	attron($$window, A_BOLD);	
	addstr($$window, 0, 0, "    Score Summary    ");
	attroff($$window, A_BOLD);	
	addstr($$window, 1, 0, " B     Qs  M1  M2  D ");
	addstr($$window, $y, 0, sprintf(" ALL %4d %3d %3d          ", $t_qso, 
				$t_mult1, $t_mult2));
	addstr($$window, 9, 0, " Total: $s_sum                ");

	refresh($$window);

}



sub count {
		my @a = split(/\s+/, $_[0]);

		return $#a;
}


return 1;
