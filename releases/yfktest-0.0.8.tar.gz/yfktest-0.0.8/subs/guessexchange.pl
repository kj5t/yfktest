
# FOC marathon
my %foc;
if (-e 'call_no_name.txt') {

open FOC, 'call_no_name.txt';
my $line;
while ($line = <FOC>) {
	map {s/\r//g;} ($line);
	chomp($line);
	$line =~ s/"//g;
	my @a = split(/,/, $line);
	$foc{$a[0]} = $a[1];	# Call = Name, Nr
}
close FOC;

}



sub guessexchange {
	if ($main::contest eq 'CQWW') {
		if ($main::lastguessed eq $main::qso{call}) {		# only guess once!
			return '';
		}
		my $zone = (&dxcc($main::qso{call}))[1];
		if ($zone) {
			$main::lastguessed = $main::qso{call};
			return $zone;
		}
		else {				# invalid call?
			return '';
		}
	} # CQWW
	elsif ($main::contest eq 'FOC') {
		if ($main::lastguessed eq $main::qso{call}) {
			return '';
		}
		if (defined($foc{$main::qso{call}})) {
			return $foc{$main::qso{call}}
		}
	}
	elsif ($main::contest =~ /ARRLDX/) {	# Guess States/Power
		if ($main::lastguessed eq $main::qso{call}) {
			return '';
		}
		if (defined($main::guesshash{$main::qso{call}})) {
			return $main::guesshash{$main::qso{call}}
		}
	}
	
}	
	
return 1;
