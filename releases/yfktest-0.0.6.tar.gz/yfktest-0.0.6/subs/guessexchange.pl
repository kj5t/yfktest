
sub guessexchange {
	if ($main::contest eq 'CQWW') {
		if ($main::lastguessed eq $main::qso{call}) {		# only guess once!
			print STDERR "Already guessed.\n";
			return '';
		}
		my $zone = (&dxcc($main::qso{call}))[1];
		if ($zone) {
			print STDERR "Guessed: $zone\n";
			$main::lastguessed = $main::qso{call};
			return $zone;
		}
		else {				# invalid call?
			return '';
		}
	} # CQWW
}	
	
return 1;
