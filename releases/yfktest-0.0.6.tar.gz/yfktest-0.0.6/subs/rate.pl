sub rate {
		$window = $_[0];
		@qsos = @{$_[1]};

		if ($#qsos > 9) {
			my $start = $qsos[$#qsos-10]{'utc'};
			my $stop = $qsos[$#qsos]{'utc'};

			$start = substr($start,0,2)*60+substr($start,2,2);	#minutes
			$stop = substr($stop,0,2)*60+substr($stop,2,2);

			if ($start == $stop) { $stop++ };

			if ($stop < $start) {
					$stop += 24*60;
			}

			my $last10 = 600/($stop-$start);

			addstr($$window, 1,0, " Last 10: ".sprintf("%3.1f   ", $last10));

			if ($#qsos > 60) {
				my $start = $qsos[$#qsos-60]{'utc'};
				$start = substr($start,0,2)*60+substr($start,2,2);	#minutes
			
				if ($stop < $start) {
					$stop += 24*60;
				}
	
				my $last60 = 6000/($stop-$start);

				addstr($$window, 2,0, " Last 60: ".sprintf("%3.1f   ", $last60));
			}

		}

		refresh($$window);



}

return 1;
